rm(list=ls());if(is.null(dev.list()["RStudioGD"])){} else {dev.off(dev.list()["RStudioGD"])};cat("\014") 
source('K_startup.R')
# --------
# example of the win_out() funktion
# y values (eg fst) in format:
# contigNAME \t xPos \t value \t contigSTART
testdf <- read.csv('test_values.txt',sep='\t');testdf %>% tail()
# get contig sizes (basicaly the reference.fai) - only needed for siliding window
testSIZE <- read.csv('test.fa.fai',sep='\t',header=F)[,1:2];testSIZE %>% head()

windowsize = 15

# running the window functions
win_NO<- mean_window_NO(testdf$x,testdf$y,testdf$group,windowsize,testdf$groupStart)
win_NEIGH <-  mean_window_neighbor(testdf$x,testdf$y,testdf$group,windowsize,testdf$groupStart)
win_SLIDE<- mean_window_slide(testdf$x, testdf$y, testdf$group, windowsize,testdf$groupStart,testSIZE,5)

# anoying formating stuff :()
names(win_NEIGH) <- c("xMEAN","y","start","group","yMEAN","yN")
dno <- as.data.frame(matrix(unlist(win_NO[[1]]), ncol=4)); names(dno) <- c("xMEAN","yMEAN","start","group")
dno$xMEAN <- as.numeric(as.character(dno$xMEAN));dno$yMEAN <- as.numeric(as.character(dno$yMEAN));
d1 <- dno %>% select(xMEAN,yMEAN,group) %>% mutate(type = 'non-overlap')
d2 <- win_NEIGH %>% select(xMEAN,yMEAN,group) %>% mutate(type = 'neighbor')
d3 <- win_SLIDE %>% select(xMEAN,yMEAN,group) %>% mutate(type = 'sliding')

# summary table
data <-  d1 %>% rbind(d2,d3)

# plot
ggplot(data,aes(xMEAN,yMEAN,col=group))+ geom_line(aes(lty=type))+
  geom_point(data =testdf,aes(x,y,col=group),alpha = .3)
