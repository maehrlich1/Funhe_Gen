# -------- K startup -------------------
library(dplyr)
library(ggplot2)
library(cowplot)
library(gridExtra)
library(stringr)
library(grid)
library(reshape2)
# ---------- K functions -------------------
# ---------- operators ------------
"%!in%" <- function(x,table) match(x,table, nomatch = 0) == 0 

# --------------------- neighbor window function ---------------------------
# x,y,group,LG_start,windowsize
mean_window_neighbor <- function(x,y,group,windowsize,start){
  dat <- as.data.frame(cbind(x,y,start)); dat$group <- factor(group)
  grp <- levels(dat$group)
  OUT <- as.data.frame(rbind(rep(NA,6)),row.names = NULL); names(OUT) <- c('x','y','start','group','yMEAN','yN')
  subroutine <- function(SUBdat,windowsize){
    yMEAN <- c();yN <- c();
    for(k in SUBdat$x){
      yMEAN <- c(yMEAN,mean(SUBdat$y[between(SUBdat$x,k-.5*windowsize,k+.5*windowsize)]));
      yN <- c(yN,sum(between(SUBdat$x,k-.5*windowsize,k+.5*windowsize)));
    }
    SUBout <-cbind(SUBdat,yMEAN,yN)
    return(SUBout)
  }
  #for(k in grp){ OUT <- rbind(OUT,subroutine(dat[dat$group == grp,],windowsize))}
  for(k in grp){ OUT <- rbind(OUT,subroutine(dat[dat$group == k,],windowsize))}
  OUT <- OUT %>% filter(!is.na(x)); OUT$group <- as.factor(OUT$group)
  return(OUT)
} 
# -------------------- sliding windows -----------------------------------
mean_window_slide <- function(x,y,group,windowsize,start,LGsizes,shiftSIZE){
  dat <- as.data.frame(cbind(x,y,start)); dat$group <- factor(group)
  grp <- levels(dat$group)
  #OUT <- as.data.frame(rbind(rep(NA,6)),row.names = NULL); names(OUT) <- c('x','y','start','group','yMEAN','yN')
  OUT <- as.data.frame(rbind(rep(NA,4)),row.names = NULL); names(OUT) <- c('xMEAN','yMEAN','yN','LGs')
  subroutine <- function(SUBdat,windowsize,LGsize,shiftSIZE){
    xMEAN <- c(); yMEAN <- c();yN <- c();LGs <- c();
    MIDpoints <-   seq((SUBdat$start[1]+.5*windowsize),(LGsize+SUBdat$start[1]-.5*windowsize),shiftSIZE)
    for(k in MIDpoints){
      xMEAN <- c(xMEAN,k)
      yMEAN <- c(yMEAN,mean(SUBdat$y[between(SUBdat$x,k-.5*windowsize,k+.5*windowsize)]));
      yN <- c(yN,sum(between(SUBdat$x,k-.5*windowsize,k+.5*windowsize)));
      LGs <- c(LGs,as.character(SUBdat$group[1]))
    }
    length(xMEAN);length(yMEAN);length(yN);length(LGs);
    SUBout <-cbind(xMEAN,yMEAN,yN,LGs)
    return(SUBout)
  }
  for(k in grp){LGsize <- LGsizes[LGsizes[,1] == k,2];OUT <- rbind(OUT,subroutine(dat[dat$group == k,],windowsize,LGsize,shiftSIZE))}
  OUT <- OUT %>% filter(!is.na(xMEAN)); OUT$LGs <- as.factor(as.character(OUT$LGs))
  OUT$xMEAN <- as.numeric(OUT$xMEAN);OUT$yMEAN <- as.numeric(OUT$yMEAN);OUT$yN <- as.numeric(OUT$yN);
  names(OUT) <- c('xMEAN','yMEAN','yN','group')
  return(OUT)
} 

# ------------------------------------------------------------------------
#non overlapping window function
# mean_values: out[[1]][2,], breaks: out[[2]][2,], raw_data: out[[3]][]
mean_window_NO <- function(x,y,groupIN,windowsize,Xstrt){
  # ----> sliding window CORE <----
  # mean_values: out[[1]][2,], breaks: out[[2]][2,], raw_data: out[[3]][]
  each_group <- function(x,y,windowsize,Xstarts){
    wrk_df <- as.data.frame(cbind(x,y))
    steps <- ceiling(max(c((max(x)-min(x))/windowsize,1),na.rm = T));
    brks <- min(Xstarts)+(1:(steps+1)-1)*windowsize;
    wrk_df$winds <- findInterval(wrk_df$x, brks)#rep(1:steps,each = windowsize)[1:length(x)];
    xMEAN <- tapply(wrk_df$x,wrk_df$winds,mean);
    X_start_bin <- tapply(wrk_df$winds,wrk_df$winds,min);
    yMEAN <- tapply(wrk_df$y,wrk_df$winds,mean)
    xSTART <- brks[X_start_bin]
    out <- as.data.frame(cbind(xMEAN,yMEAN,xSTART))  
    return(list(out,brks,wrk_df))
  }
  # ---> Contig Loop <----
  xMEAN <-c(NA);xSTART <-c(NA);xEND <-c(NA);yMEAN <-c(NA);group<-c(NA);x1<-c(NA);y1<-c(NA);win1<-c(NA);
  results <-list(cbind(xMEAN,yMEAN,start,group),c(),cbind(x1,y1,win1,group))
  grps <- levels(as.factor(groupIN))
  BIG_df <- as.data.frame(cbind(x,y,groupIN))
  BIG_df$x <- as.numeric(as.character(BIG_df$x)); 
  BIG_df$y <- as.numeric(as.character(BIG_df$y))
  BIG_df$Xstrt <- Xstrt
  for(k in grps){ind <- each_group(BIG_df[groupIN==k,1],BIG_df[groupIN==k,2],windowsize,BIG_df[groupIN==k,4])
  ind_g <- cbind(ind[[1]],rep(k,length(ind[[1]][,1])));names(ind_g) <- c('xMEAN','yMEAN','start','group')
  ind_g3 <- cbind(ind[[3]],rep(k,length(ind[[3]][,1])));names(ind_g3) <- c('x1','y1','win1','group')
  results <- list(rbind(results[[1]],ind_g),c(results[[2]],ind[[2]]),rbind(results[[3]],ind_g3))}
  results[[1]] <- results[[1]][-1,];results[[3]] <- results[[3]][-1,]
  return(results)
}

#----------------------
# funtion to group neighbouring outliers
parseOUTLIERS <- function(dataPLOT,windowsize){
  #  requires windowsize=numeric and dataPLOT like:
  #    X_mean       Y_mean Contig outSTAT outSTAT_contig
  # 1       3    0.2952026      A       0             A0
  # 2       8    0.3817794      A       0             A0
  OUTL <- dataPLOT %>% filter(outSTAT ==1) %>% group_by(Contig) %>% mutate(middle = as.numeric(X_mean-lag(X_mean)==windowsize |lead(X_mean)-X_mean==windowsize)) %>% mutate(OUTL_group = NA)
  ogr <- 1
  for (k in 1:length(OUTL$OUTL_group)) {if(OUTL$middle[k]==0| is.na(OUTL$middle[k])){ OUTL$OUTL_group[k]=ogr;ogr=ogr+1} 
    else if(k ==length(OUTL$OUTL_group)){OUTL$OUTL_group[k]=ogr} 
    else if(OUTL$middle[k+1]==0| is.na(OUTL$middle[k+1])|OUTL$Contig[k+1]!=OUTL$Contig[k]){ OUTL$OUTL_group[k]=ogr;ogr=ogr+1}
    else {OUTL$OUTL_group[k]=ogr}}
  outBOXraw <- OUTL %>% group_by(OUTL_group) %>% summarise(ceiling(min(X_mean)-0.5*windowsize) ,floor(max(X_mean)+0.5*windowsize)); names(outBOXraw) <- c('group','low','high')
  outBOX <- melt(outBOXraw %>% mutate(low2 = low,low3 = low, high2 = high) %>% select(group,low,high,high2,low2,low3),id.vars = 'group') %>% arrange(group)
  outBOX$y <- rep(c(min(dataPLOT$Y_mean),min(dataPLOT$Y_mean),max(dataPLOT$Y_mean),max(dataPLOT$Y_mean),min(dataPLOT$Y_mean)),length(outBOX$value)/5)
  return(outBOX)
}
